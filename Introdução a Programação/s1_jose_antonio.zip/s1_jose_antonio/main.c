#include <stdio.h>
#include <stdlib.h>

#define LIMPARTELA "cls"

//Assinatura das Fun��es
float soma(float a, float b);
float sub(float a, float b);
float mult(float a, float b);
float divi(float a, float b);

//Declara��o de Vari�veis
float num1, num2;
char op, resp;

//Programa
int main()
{
    do{
        fflush(stdin);
        system(LIMPARTELA);
        printf("================================== CALCULADORA ================================\n");
        printf("                                O que deseja fazer ?                             \n \n");
        printf("                 (+) Soma (-) Subtracao (*) Multiplicacao (/) Divisao            \n");
        printf("\n (Digite de acordo com a operacao desejada ou qualquer outro valor para sair)    \n");
        printf("===============================================================================\n");
        printf("Op = ");
        scanf("%c", &op);
        printf("\n");

        switch (op){

            case '+':
                system(LIMPARTELA);
                printf("\nDigite o primeiro valor: ");
                scanf("%f",&num1);
                printf("\nDigite o segundo valor: ");
                scanf("%f",&num2);
                printf("\nResultado = %.2f", soma(num1,num2));

                break;
            case '-':
                system(LIMPARTELA);
                printf("\nDigite o primeiro valor: ");
                scanf("%f",&num1);
                printf("\nDigite o segundo valor: ");
                scanf("%f",&num2);
                printf("\nResultado = %.2f", sub(num1,num2));
                break;
            case '*':
                system(LIMPARTELA);
                printf("\nDigite o primeiro valor: ");
                scanf("%f",&num1);
                printf("\nDigite o segundo valor: ");
                scanf("%f",&num2);
                printf("\nResultado = %.2f", mult(num1,num2));
                break;
            case '/':
                system(LIMPARTELA);
                printf("\nDigite o primeiro valor: ");
                scanf("%f",&num1);
                printf("\nDigite o segundo valor: ");
                scanf("%f",&num2);
                printf("\nResultado = %.2f", divi(num1,num2));
                break;
            default:
                getchar();
                system(LIMPARTELA);
                printf("\nOperacao invalida \n");
                break;

        }
    getchar();
    printf("\nDeseja continuar ? S/N \n");
    scanf("%c", &resp);

    } while (resp == 's' || resp == 'S');
    system(LIMPARTELA);
    printf("Calculadora encerrada\n");
    system ("pause");
    return 0;
}

//Fun��es implementadas
float soma(float a, float b)
{
    return (a + b);
}

float sub(float a, float b)
{
    return (a - b);
}

float mult(float a, float b)
{
    return (a * b);
}

float divi(float a, float b)
{
    return (a / b);
}
